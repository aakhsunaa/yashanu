from django.urls import path
from . import views

urlpatterns = [
    path('',views.dashboard),
    path('signup/',views.signup),
    path('login/',views.user_login),
    path('signup/dashboard2/',views.dashboard2),
    path('login/dashboard2/',views.dashboard2),
    path('my_profile/',views.my_profile),
    path('my_profile/update/',views.update_view),
]