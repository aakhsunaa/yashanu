from django.db import models
from django.contrib.auth.models import User

from requests.api import request

# Create your models here.

class Profile(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
#this is was for the expansion of the User model with some extra fields 
    number_of_followers = models.IntegerField(max_length=150, null=True)
    date_updated= models.DateTimeField(max_length=150,null=True)
    time_updated = models.DateTimeField(null=True,max_length=150,blank=True)
    
    
def __str__(self):
    return self.field_name
#here i some how need tohave the connection between the repository 

class Repository(models.Model):
        profile = models.ForeignKey(Profile, on_delete=models.CASCADE)#this is many to one linkinng like many repositories have one profile
        number_of_stars = models.IntegerField(max_length=100)
def __str__(self):
    return self.field_name



    

