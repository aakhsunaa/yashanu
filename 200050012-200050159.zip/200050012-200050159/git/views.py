from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages
from .forms import NewUserForm, User
from requests.api import request
from requests.auth import HTTPBasicAuth
import requests
# Create your views here.
def dashboard(request):
    return render(request,'git/dashboard.html')

def dashboard2(request):
    return render(request,'git/dashboard2.html')

def signup(request):
    if request.method == 'POST':
        form = NewUserForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Registration Successful")
            return redirect("dashboard2/")
        messages.error(request, "Unsuccessful Registration. Invalid information")
    form = NewUserForm()
    return render(request,'git/signup.html',context={"form":form})

def user_login(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request,user)
                messages.info(request, f"You are now logged in as {username}")
                return redirect("dashboard2/")
            else:
                messages.error(request,"Invalid username or password.")
        else:
            messages.error(request,"Invalid username or password.") 
    form = AuthenticationForm()
    return render(request,'git/login.html',context={"login_form":form})

#class fetchdata(TemplateView):
 #   template_name = 'my_profile.html'
  #  def get_context_data(self, *args, **kwargs):
   
   #     context = {
    #        'data' : fetch(),
     #   }
      #  return context


def my_profile(request):
    context = {}
    username = request.user.username
    profile_stat = requests.get(f"https://api.github.com/users/{username}")
    data = profile_stat.json()
    repo = []
    reposits = requests.get(f"https://api.github.com/users/{username}/repos")
    data2 = reposits.json()
    for r in data2:
        a = {}
        a['repo_name'] = r['name']
        a['stars'] = r['stargazers_count']
        repo.append(a)
    repo_names = []
    for i in repo:
        repo_names.append(i['repo_name'])
    repo_stars = []
    for i in repo:
        repo_stars.append(i['stars'])
    context ={'username':username,'name':request.user.first_name,'no_of_followers':data['followers'],'last_updated':data['updated_at']
    ,'repo':repo}
    return render(request, 'git/my_profile.html',context)

def update_view(request):
    context = {}
    username = request.user.username
    profile_stat = requests.get(f"https://api.github.com/users/{username}")
    data = profile_stat.json()
    repo = []
    reposits = requests.get(f"https://api.github.com/users/{username}/repos")
    data2 = reposits.json()
    for r in data2:
        a = {}
        a['repo_name'] = r['name']
        a['stars'] = r['stargazers_count']
        repo.append(a)
    repo_names = []
    for i in repo:
        repo_names.append(i['repo_name'])
    repo_stars = []
    for i in repo:
        repo_stars.append(i['stars'])
    context ={'username':username,'name':request.user.first_name,'no_of_followers':data['followers'],'last_updated':data['updated_at']
    ,'repo':repo}
    return render(request, 'git/my_profile.html',context)
    
def user_logout(request):
    logout(request)
    messages.info(request, "You have successfully logged out")
    return redirect("http://127.0.0.1:8000/")

